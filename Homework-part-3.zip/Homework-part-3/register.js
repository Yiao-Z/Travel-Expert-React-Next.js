const registrationForm = document.querySelector("#registrationForm");
const passwordInput = document.querySelector("#password");
const confirmPasswordInput = document.querySelector("#confirmPassword");
const submitButton = document.querySelector('input[type="submit"]');
const resetButton = document.querySelector('button[type="reset"]');
const travelPreferences = document.querySelector("#travelPreferences");

const requestedPreference = new URLSearchParams(window.location.search).get("preference");
const availablePreferences = Array.from(travelPreferences.options, (option) => option.value);

/*request access from contact page*/
if (availablePreferences.includes(requestedPreference)) {
    travelPreferences.value = requestedPreference;
}

//password validation//
function validatePasswords() {
    if (confirmPasswordInput.value !== passwordInput.value) {
        confirmPasswordInput.setCustomValidity("Passwords must match.");
        return false;
    }

    confirmPasswordInput.setCustomValidity("");
    return true;
}

passwordInput.addEventListener("input", validatePasswords);
confirmPasswordInput.addEventListener("input", validatePasswords);

/*confirmation pop up*/
registrationForm.addEventListener("submit", (event) => {
    if (!validatePasswords()) {
        event.preventDefault();
        confirmPasswordInput.reportValidity();
        return;
    }

    if (!window.confirm("Are you sure you want to submit this registration?")) {
        event.preventDefault();
    }
});

//button coloration//
submitButton.addEventListener("mouseenter", () => {
    submitButton.style.backgroundColor = "#126782";
});

submitButton.addEventListener("mouseleave", () => {
    submitButton.style.backgroundColor = "#219ebc";
});

resetButton.addEventListener("mouseenter", () => {
    resetButton.style.backgroundColor = "#219ebc";
});

resetButton.addEventListener("mouseleave", () => {
    resetButton.style.backgroundColor = "#126782";
});

registrationForm.addEventListener("click", () => {
    registrationForm.classList.toggle("form-selected");
});