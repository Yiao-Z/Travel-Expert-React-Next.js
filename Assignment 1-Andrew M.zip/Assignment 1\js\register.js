/*
        File: register.js
        Purpose: Adds contextual field guidance and confirmation prompts to the
        registration form.

        Some of the code in this assisgment is from the help of AI.

        Behavior:
            - Hides field guidance on page load and shows the relevant guidance on focus.
            - Confirms before submitting or resetting the form, canceling either action
                when the visitor declines.
            - Confirms password and tells you if the password do not match
*/
const submitButton = document.querySelector('button[type="submit"]');
const resetButton = document.querySelector('button[type="reset"]');
const registrationForm = document.querySelector("form");
const passwordField = document.getElementById("password");
const confirmPasswordField = document.getElementById("confirm_password");
const emailField = document.getElementById("email");
const textFields = document.querySelectorAll('input:not([type="hidden"]), textarea');
const fieldHelp = document.querySelectorAll(".field-help");
const registrationParams = new URLSearchParams(window.location.search);
const destinationSelect = document.getElementById("Travel_where");
const travelTypeSelect = document.getElementById("travel_type");

const destination = registrationParams.get("destination");
if (destination && [...destinationSelect.options].some((option) => option.value === destination)) {
    destinationSelect.value = destination;
}

const travelType = registrationParams.get("type");
if (travelType && [...travelTypeSelect.options].some((option) => option.value === travelType)) {
    travelTypeSelect.value = travelType;
}

const validateEmail = () => {
    const emailPattern = /^[^\s@]+@[^\s@.]+(?:\.[^\s@.]+)+$/;
    const emailIsValid = emailField.value === "" || emailPattern.test(emailField.value);

    emailField.setCustomValidity(
        emailIsValid ? "" : "Enter a valid email address, like name@example.com."
    );
};

emailField.addEventListener("input", validateEmail);
emailField.addEventListener("change", validateEmail);
validateEmail();

const validatePasswordMatch = () => {
    confirmPasswordField.setCustomValidity(
        confirmPasswordField.value === passwordField.value ? "" : "Passwords do not match."
    );
};

passwordField.addEventListener("input", validatePasswordMatch);
confirmPasswordField.addEventListener("input", validatePasswordMatch);
registrationForm.addEventListener("reset", () => {
    window.setTimeout(validatePasswordMatch, 0);
});

fieldHelp.forEach((paragraph) => {
    paragraph.classList.remove("is-visible");
});

textFields.forEach((field) => {
    field.addEventListener("focus", () => {
        fieldHelp.forEach((paragraph) => {
            paragraph.classList.remove("is-visible");
        });

        const helpParagraph = document.getElementById(field.getAttribute("aria-describedby"));
        helpParagraph.classList.add("is-visible");
    });
});

submitButton.addEventListener("click", (event) => {
    if (!confirm("Are you sure you want to submit this form?")) {
        event.preventDefault();
    }
});

resetButton.addEventListener("click", (event) => {
    if (!confirm("Are you sure you want to reset this form?")) {
        event.preventDefault();
    }
});
