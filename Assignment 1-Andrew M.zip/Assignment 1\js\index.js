/*
        File: index.js
        Purpose: Creates the destination description rows and connects them to image
        previews and destination websites.

        Some of the code in this assisgment is from the help of AI.
    
        Behavior:
            - Clicking a destination displays its image.
            - Clicking the preview image opens the matching website URL in a new window.
            - The opened website window is closed after 20 seconds when permitted by the browser.
*/
const images = [
    { src: "img/mt fuji.jpeg", alt: "Mount Fuji in Japan" },
    { src: "img/europe-scenery.jpg", alt: "Scenery in Europe" },
    { src: "img/lake scenery.jpg", alt: "A peaceful lake destination" }
];

const descriptions = [
    "Visit Mount Fuji and experience the beauty of Japan.",
    "Explore the historic cities and scenery of Europe.",
    "Relax beside a peaceful lake and enjoy the natural surroundings."
];

const websiteURLs = [
    "https://www.japan.travel/en/fuji-guide/mt-fuji-more-than-a-mountain/",
    "https://visiteurope.com/",
    "https://parks.canada.ca/pn-np/ab/banff"
];

function showImage(index) {
    const imagePreview = document.querySelector("#image-preview");

    imagePreview.innerHTML = `<img src="${images[index].src}" alt="${images[index].alt}">`;
    imagePreview.querySelector("img").addEventListener("click", () => openWebsite(index));
}

function openWebsite(index) {
    const websiteWindow = window.open(websiteURLs[index], "_blank");

    if (websiteWindow) {
        window.setTimeout(() => websiteWindow.close(), 20000);
    }
}

window.addEventListener("load", () => {
    const tableBody = document.querySelector("#image-table-body");

    for (let index = 0; index < images.length; index += 1) {
        const row = document.createElement("tr");
        const descriptionCell = document.createElement("td");
        const destinationButton = document.createElement("button");

        destinationButton.type = "button";
        destinationButton.textContent = descriptions[index];
        destinationButton.setAttribute("aria-pressed", "false");
        destinationButton.addEventListener("click", () => {
            showImage(index);
            tableBody.querySelectorAll("button").forEach((button, buttonIndex) => {
                button.setAttribute("aria-pressed", String(buttonIndex === index));
            });
        });
        descriptionCell.append(destinationButton);
        row.append(descriptionCell);
        tableBody.append(row);
    }
});
