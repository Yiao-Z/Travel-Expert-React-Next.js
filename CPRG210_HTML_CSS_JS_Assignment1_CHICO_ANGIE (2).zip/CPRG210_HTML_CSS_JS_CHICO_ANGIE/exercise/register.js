const registrationForm = document.getElementById("registration-form");
const submitButton = document.getElementById("submit-button");
const resetButton = document.getElementById("reset-button");
let submissionConfirmed = false;

const helpParagraphs = registrationForm.querySelectorAll(".field-help");
const guidedFields = registrationForm.querySelectorAll("input:not([type='radio']), textarea");

guidedFields.forEach((field) => {
    field.addEventListener("focus", () => {
        helpParagraphs.forEach((paragraph) => {
            paragraph.hidden = true;
        });

        const helpId = field.getAttribute("aria-describedby");
        const helpParagraph = helpId ? document.getElementById(helpId) : null;
        if (helpParagraph) {
            helpParagraph.hidden = false;
        }
    });

    field.addEventListener("blur", () => {
        const helpId = field.getAttribute("aria-describedby");
        const helpParagraph = helpId ? document.getElementById(helpId) : null;
        if (helpParagraph) {
            helpParagraph.hidden = true;
        }
    });
});

submitButton.addEventListener("click", (event) => {
    if (!registrationForm.reportValidity()) {
        event.preventDefault();
        return;
    }

    if (!window.confirm("Submit this registration?")) {
        event.preventDefault();
        return;
    }

    submissionConfirmed = true;
});

registrationForm.addEventListener("submit", (event) => {
    event.preventDefault();

    if (!submissionConfirmed && !window.confirm("Submit this registration?")) {
        return;
    }

    submissionConfirmed = false;
    window.location.assign("confirmation.html");
});

resetButton.addEventListener("click", (event) => {
    if (!window.confirm("Reset all registration fields?")) {
        event.preventDefault();
    }
});