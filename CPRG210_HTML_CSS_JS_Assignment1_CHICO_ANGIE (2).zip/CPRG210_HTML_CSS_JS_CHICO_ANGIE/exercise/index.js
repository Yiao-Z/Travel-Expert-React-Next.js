const destinationImages = [
    { src: "images/travel1.avif", alt: "Calgary city and surrounding landscape" },
    { src: "images/travel2.avif", alt: "Calgary Tower" },
    { src: "images/travel3.avif", alt: "A scenic Southern Alberta road trip" }
];

const destinationDescriptions = [
    "Discover Calgary's neighborhoods, culture, and nearby mountain views.",
    "See Calgary from above at the landmark Calgary Tower.",
    "Explore the landscapes and stops along a Southern Alberta road trip."
];

const destinationUrls = [
    "https://www.travelalberta.com/places-to-go/cities-towns/calgary",
    "https://www.travelalberta.com/listings/calgary-tower-1097",
    "https://www.travelalberta.com/trip-ideas/road-trips-itineraries/southern-alberta-adventures-from-calgary"
];

const destinationList = document.getElementById("destinations");
function openDestination(index) {
    const destinationWindow = window.open(
        destinationUrls[index],
        "_blank",
        "popup,width=1000,height=700"
    );

    if (!destinationWindow) {
        window.location.assign(destinationUrls[index]);
        return;
    }

    window.setTimeout(() => {
        if (!destinationWindow.closed) {
            destinationWindow.close();
        }
    }, 7000);
}

destinationImages.forEach((image, index) => {
    const destinationLink = document.createElement("a");
    destinationLink.className = "destination-card";
    destinationLink.href = destinationUrls[index];
    destinationLink.target = "_blank";
    destinationLink.rel = "noopener noreferrer";

    const destinationImage = document.createElement("img");
    destinationImage.src = image.src;
    destinationImage.alt = image.alt;
    destinationImage.loading = "lazy";

    const description = document.createElement("span");
    description.className = "destination-description";
    description.textContent = destinationDescriptions[index];

    destinationLink.append(destinationImage, description);
    destinationLink.addEventListener("click", (event) => {
        event.preventDefault();
        openDestination(index);
    });
    destinationList.append(destinationLink);
});